<?php

/**
 * Listings - Category
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'Netlink_Shop_Listing_Category' ) ) {

    class Netlink_Shop_Listing_Category {

        private static $_instance = null;

        private $settings;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            /* Load Modules */
                $this->load_modules();

        }

        /*
        Load Modules
        */
            function load_modules() {

                /* Customizer */
                    include_once NETLINK_SHOP_PATH . 'modules/category/customizer/index.php';

            }

    }

}


if( !function_exists('netlink_shop_listing_category') ) {
	function netlink_shop_listing_category() {
		return Netlink_Shop_Listing_Category::instance();
	}
}

netlink_shop_listing_category();