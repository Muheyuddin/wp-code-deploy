===== Netlink Shop =====

Netlink Shop plugin adds shop features for Netlink theme.


== Changelog ==

= 1.0.0 =

    * First release!