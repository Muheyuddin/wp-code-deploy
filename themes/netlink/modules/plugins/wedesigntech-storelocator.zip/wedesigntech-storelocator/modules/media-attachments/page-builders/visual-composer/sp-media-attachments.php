<?php
add_action( 'vc_before_init', 'dtsl_sp_media_attachments_vc_map' );

function dtsl_sp_media_attachments_vc_map() {

	$dt_sl_listing_singular_label = apply_filters( 'dt_sl_listing_label', 'singular' );

	vc_map( array(
		"name" => esc_html__( 'Media - Attachments', 'dtsl' ),
		"base" => "dtsl_sp_media_attachments",
		"icon" => "dtsl_sp_media_attachments",
		"category" => DTSL_PB_MODULE_SINGLEPAGE_TITLE,
		"params" => array(

			// Listing Id
			array(
				'type' => 'textfield',
				'heading' => sprintf( esc_html__('%1$s Id', 'dtsl'), $dt_sl_listing_singular_label ),
				'param_name' => 'listing_id',
				'description' => sprintf( esc_html__('Provide %1$s id for which you have to display featured image. No need to provide ID if it is used in %1$s single page.', 'dtsl'), strtolower($dt_sl_listing_singular_label) ),
				'edit_field_class' => 'vc_column vc_col-sm-6',
				'admin_label' => true
			),

			// Type
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Type','dtsl'),
				'param_name' => 'type',
				'value' => array(
					esc_html__( 'Type 1', 'dtsl' ) => 'type1',
					esc_html__( 'Type 2', 'dtsl' ) => 'type2',
					esc_html__( 'Type 3', 'dtsl' ) => 'type3',
					esc_html__( 'Type 4', 'dtsl' ) => 'type4',
					esc_html__( 'Type 5', 'dtsl' ) => 'type5'
				),
				'description' => esc_html__('Choose type of layout you like to display.', 'dtsl'),
				'edit_field_class' => 'vc_column vc_col-sm-6',
				'std' => 'type1',
			),

			// Class
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Class', 'dtsl' ),
				'param_name' => 'class',
				'description' => esc_html__( 'If you wish you can add additional class name here.', 'dtsl' ),
				'edit_field_class' => 'vc_column vc_col-sm-6'
			),

		)
	) );
}
?>